import "./../box2d.wasm.js";
import "./c3runtime.js";
import "./plugins/ppstudio_lolapi/c3runtime/main.js";
import "./objRefTable.js";
